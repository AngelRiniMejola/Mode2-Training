package com.example.demo.Model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="showtab")
public class Show {
	@Id
	private String showId;
	private String theatreId;
	private LocalDate date;
	private String mornshow;
	private String noonshow;
	private String eveshow;
	
	
	public String getShowId() {
		return showId;
	}
	public void setShowId(String showId) {
		this.showId = showId;
	}
	public String getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(String theatreId) {
		this.theatreId = theatreId;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getMornshow() {
		return mornshow;
	}
	public void setMornshow(String mornshow) {
		this.mornshow = mornshow;
	}
	public String getNoonshow() {
		return noonshow;
	}
	public void setNoonshow(String noonshow) {
		this.noonshow = noonshow;
	}
	public String getEveshow() {
		return eveshow;
	}
	public void setEveshow(String eveshow) {
		this.eveshow = eveshow;
	}
	
	
	
}
