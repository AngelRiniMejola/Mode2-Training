package com.example.demo.Dto;

public class ShowDto {

	String showSearch;

	public String getShowSearch() {
		return showSearch;
	}

	public void setShowSearch(String showSearch) {
		this.showSearch = showSearch;
	}
	
}
