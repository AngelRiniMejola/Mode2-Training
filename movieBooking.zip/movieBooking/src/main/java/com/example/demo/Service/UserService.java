package com.example.demo.Service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.TheatreDao;
import com.example.demo.Dao.UserDao;
import com.example.demo.Model.Theatre;
import com.example.demo.Model.User;

@Service
public class UserService {

	@Autowired
	private UserDao userdao;

	//To add user details
	@Transactional
	public String addUser(User user) {
		userdao.save(user);
		return "Successfully added User Details";

	}
}
