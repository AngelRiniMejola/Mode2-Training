package com.example.demo.Dao;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.Model.Movie;

public interface MovieDao extends CrudRepository<Movie,String> { 

}
