package com.example.demo.Service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.TheatreDao;
import com.example.demo.Model.Theatre;

@Service
public class TheatreService {

	@Autowired
	private TheatreDao theatredao;

	//To add theatre details
	@Transactional
	public String addTheatre(Theatre theatre) {
		theatre.setTheatreId(theatre.getTheatreId());
		theatre.setTheatreName(theatre.getTheatreName());
		theatre.setPlace(theatre.getPlace());
		theatredao.save(theatre);
		return "Successfully added Theatre Details";

	}

	//To return the list of Theatres in which the particular movie is running
	public List<Theatre> find(String movieName) {
		List<Theatre> p = theatredao.findTheatre(movieName);
		return p;

	}

}
