package com.example.demo.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.Model.Theatre;

@Repository
public interface TheatreDao extends CrudRepository<Theatre,String> {

	
	@Query(value="select * from theatre t where t.theatre_id IN (select s.theatre_id from showtab s where s.mornshow=?1 or s.noonshow=?1 or s.eveshow=?1)",nativeQuery=true)
	public List<Theatre> findTheatre(String moviename);

	
	
	

}
