package com.example.demo.Dto;

import java.time.LocalDate;

public class MovieListDto {

	String theatreName;
	String place;
	String mornshow;
	String noonshow;
	String eveshow;
	LocalDate date;

	public MovieListDto() {
		super();
	}

	public MovieListDto(String theatreName, String place, String mornshow, String noonshow, String eveshow,
			LocalDate date) {
		super();
		this.theatreName = theatreName;
		this.place = place;
		this.mornshow = mornshow;
		this.noonshow = noonshow;
		this.eveshow = eveshow;
		this.date = date;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getTheatreName() {
		return theatreName;
	}

	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getMornshow() {
		return mornshow;
	}

	public void setMornshow(String mornshow) {
		this.mornshow = mornshow;
	}

	public String getNoonshow() {
		return noonshow;
	}

	public void setNoonshow(String noonshow) {
		this.noonshow = noonshow;
	}

	public String getEveshow() {
		return eveshow;
	}

	public void setEveshow(String eveshow) {
		this.eveshow = eveshow;
	}

}
