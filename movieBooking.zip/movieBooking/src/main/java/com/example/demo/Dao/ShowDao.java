package com.example.demo.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.Dto.MovieListDto;
import com.example.demo.Model.Show;
import com.example.demo.Model.Theatre;

@Repository
public interface ShowDao extends CrudRepository<Show,String> {

	@Query(value="select * from showtab s where s.mornshow=?1 or s.noonshow=?1 or s.eveshow=?1",nativeQuery=true)
	public List<Show> find(String moviename);
	}




