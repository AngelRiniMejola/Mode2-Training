package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.MovieDao;
import com.example.demo.Dao.ShowDao;
import com.example.demo.Model.Movie;

@Service
public class MovieService {
	@Autowired
	private MovieDao moviedao;

	//To add movie details
	public String addMovie(Movie movie) {
		movie.setMoviename(movie.getMoviename());
		movie.setLanguage(movie.getLanguage());
		movie.setReleasedate(movie.getReleasedate());
		moviedao.save(movie);
		return "Movie Details Successfully added";
	}

	//To get the list of movies
	public Iterable<Movie> getMovies() {
		Iterable<Movie> list = moviedao.findAll();
		return list;

	}

}
