package com.example.demo.Service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.ShowDao;
import com.example.demo.Dao.TheatreDao;
import com.example.demo.Dto.MovieListDto;
import com.example.demo.Dto.ShowDto;
import com.example.demo.Model.Show;
import com.example.demo.Model.Theatre;
import com.example.demo.exception.MovieNotFoundException;

@Service
public class ShowService {

	@Autowired
	private ShowDao showdao;
	@Autowired
	private TheatreDao theatredao;

	//To add show details
	@Transactional
	public String addShows(Show show) {
		show.setDate(show.getDate());
		show.setShowId(show.getShowId());
		show.setMornshow(show.getMornshow());
		show.setNoonshow(show.getNoonshow());
		show.setEveshow(show.getEveshow());
		show.setTheatreId(show.getTheatreId());
		showdao.save(show);
		return "Show Details added successfully";
	}

	//To check the movie in Movie list
	public String checkMovie(ShowDto showdto) throws MovieNotFoundException {
		int flag = 0;
		List<Show> list = (List<Show>) showdao.findAll();
		for (Show s : list) {
			if (showdto.getShowSearch().equalsIgnoreCase(s.getMornshow())
					|| showdto.getShowSearch().equalsIgnoreCase(s.getNoonshow())
					|| showdto.getShowSearch().equalsIgnoreCase(s.getEveshow())) {
				flag = 1;
				return "Movie is running now....!!!!!";
			}
		}
		if (flag == 0) {
			return "Movie notExists";
		}
		return null;
	}

	//To display the particular movie details
	public List<MovieListDto> showMovie(String movieName) {
		List<Show> listShow = showdao.find(movieName);
		Theatre theatre = new Theatre();
		List<MovieListDto> list = new ArrayList<>();
		for (Show value : listShow) {
			MovieListDto tshowdto = new MovieListDto();
			String theatreId = value.getTheatreId();
			theatre = theatredao.findById(theatreId).orElse(null);
			tshowdto.setTheatreName(theatre.getTheatreName());
			tshowdto.setPlace(theatre.getPlace());
			tshowdto.setMornshow(value.getMornshow());
			tshowdto.setNoonshow(value.getNoonshow());
			tshowdto.setEveshow(value.getEveshow());
			tshowdto.setDate(value.getDate());
			list.add(tshowdto);
		}
		return list;
	}

}
