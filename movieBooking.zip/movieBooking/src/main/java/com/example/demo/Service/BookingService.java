package com.example.demo.Service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.BookingDao;
import com.example.demo.Dao.ShowDao;
import com.example.demo.Dao.TheatreDao;
import com.example.demo.Model.Booking;
import com.example.demo.Model.Show;
import com.example.demo.Model.Theatre;

@Service
public class BookingService {
	@Autowired
	BookingDao bookingdao;
	@Autowired
	TheatreDao theaterdao;
	@Autowired
	ShowDao showdao;

	// To book a Movieticket
	public Booking addBooking(String movieName, String theatreId, String showTime, int userId) {
		Theatre theatre = theaterdao.findById(theatreId).orElse(null);
		Show show = showdao.findById(theatreId).orElse(null);
		Booking b = new Booking();
		b.setUserId(userId);
		b.setShowTime(showTime);
		b.setMoviename(movieName);
		b.setTheatreName(theatre.getTheatreName());
		b.setDate(LocalDate.now());
		return bookingdao.save(b);

	}

}
