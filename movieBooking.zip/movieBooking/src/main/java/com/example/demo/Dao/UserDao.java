package com.example.demo.Dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Model.Theatre;
import com.example.demo.Model.User;

@Repository
public interface UserDao extends CrudRepository<User,String> {

	 
}
