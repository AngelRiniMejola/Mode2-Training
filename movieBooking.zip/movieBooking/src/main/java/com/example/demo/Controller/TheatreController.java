package com.example.demo.Controller;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Dto.MovieListDto;
import com.example.demo.Dto.ShowDto;
import com.example.demo.Model.Booking;
import com.example.demo.Model.Movie;
import com.example.demo.Model.Show;
import com.example.demo.Model.Theatre;
import com.example.demo.Model.User;
import com.example.demo.Service.BookingService;
import com.example.demo.Service.MovieService;
import com.example.demo.Service.ShowService;
import com.example.demo.Service.TheatreService;
import com.example.demo.Service.UserService;
import com.example.demo.exception.MovieNotFoundException;

@RestController
public class TheatreController {
	private static final Logger logger = LoggerFactory.getLogger(TheatreController.class);

	@Autowired
	private TheatreService theatreService;
	@Autowired
	private ShowService showService;
	@Autowired
	private MovieService movieService;
	@Autowired
	private UserService userService;
	@Autowired
	BookingService bookingservice;

	@PostMapping(value = "/add/theatre")
	public String addTheatreDetails(@RequestBody Theatre theatre) {
		String str = theatreService.addTheatre(theatre);
		return str;
	}

	@PostMapping(value = "/add/show")
	public String addShowDetails(@RequestBody Show show) {
		String str = showService.addShows(show);
		return str;
	}

	@PostMapping(value = "/add/movie")
	public String addMovieDetails(@RequestBody Movie movie) {
		String str = movieService.addMovie(movie);
		return str;
	}

	@PostMapping(value = "/add/user")
	public String addUserDetails(@RequestBody User user) {
		String str = userService.addUser(user);
		return str;
	}


	@PostMapping(value = "/show/search")
	public String showSearch(@RequestBody ShowDto showdto) throws MovieNotFoundException {
		String str = showService.checkMovie(showdto);
		return str;
	}

	@GetMapping(value = "/show/get/{movieName}")
	public List<Theatre> getshow(@PathVariable String movieName) {
		List<Theatre> p = theatreService.find(movieName);
		return p;
	}

	@GetMapping(value = "/getDetails")
	public List<MovieListDto> findMovieName(@RequestParam(value = "movieName") String movieName) {
		System.out.println("entering..");
		List<MovieListDto> list = showService.showMovie(movieName);
		return list;
	}

	@PostMapping(value = "/add/booking")
	public Booking addShowDetails(@RequestParam String movieName, @RequestParam String theatreId,
			@RequestParam String showTime, @RequestParam int userId) {
		return (Booking) bookingservice.addBooking(movieName, theatreId, showTime, userId);

	}
	
	@GetMapping(value="movie/getAll")
	public Iterable<Movie> getAllMovies(){
	return	movieService.getMovies();
		
	}

}
