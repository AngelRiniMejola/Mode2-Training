import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class MainBank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter numbers");
		int a = sc.nextInt();
		ArrayList<Integer> al = new ArrayList<Integer>();

		for (int i = 0; i < a; i++) {
			al.add(sc.nextInt());

		}

		List<String> a2 = al.stream().map(p -> "SBI" + p).collect(Collectors.toList());
		System.out.println(a2);

		List<String> valid = a2.stream().filter(i -> i.length() == 8).collect(Collectors.toList());
		long count = valid.stream().filter(i -> !i.isEmpty()).count();

		System.out.println("valid accounts are:" + valid);
		System.out.println("valid customers are:" + count);

		List<String> invalid = a2.stream().filter(i -> i.length() != 8).collect(Collectors.toList());
		System.out.println("invalid accounts are:" + invalid);

		Customer[] c = new Customer[20];

		String name;

		int age;

		long phoneNo;

		String accNo;

		float amount;

		float bal;

		List<Customer> listed = new ArrayList<Customer>();

		for (int i = 0; i < valid.size(); i++) {

			name = sc.next();

			age = sc.nextInt();

			phoneNo = sc.nextLong();

			accNo = valid.get(i);

			bal = sc.nextFloat();

			c[i] = new Customer(age, name, phoneNo, accNo, bal);

			listed.add(c[i]);

		}

		List<Customer> res = listed.stream().filter(x -> x.name.matches("^[A-Z][a-zA-Z]{2,30}$") && (x.age > 18)
				&& (String.valueOf(x.phoneNo).matches("^[1-9][0-9]{2,10}$"))).collect(Collectors.toList());
		List<Customer> fail = listed.stream().filter(x -> !(x.name.matches("^[A-Z][a-zA-Z]{2,30}$") && (x.age > 18)
				&& (String.valueOf(x.phoneNo).matches("^[1-9][0-9]{2,10}$")))).collect(Collectors.toList());
		System.out.println("Valid Accounts");
		res.forEach((temp) -> {
			System.out.println("Name:" + temp.name + "\t Age:" + temp.age + "\t Phone No:" + temp.phoneNo + "\t Acc No:"
					+ temp.accNo + "\t Balance:" + temp.bal);
		});
		System.out.println("InValid Accounts");

		fail.forEach((tem) -> {
			System.out.println("Name:" + tem.name + "\t Age:" + tem.age + "\t Phone No:" + tem.phoneNo + "\t Acc No:"
					+ tem.accNo + "\t Balance:" + tem.bal);
		});
		List<Customer> sort = res.stream().sorted(Comparator.comparing(Customer::getName)).collect(Collectors.toList());

		int ch = 0;

		int flag = -1;

		System.out.println("Enter user name:");

		String CustomerName = sc.next();

		for (int i = 0; i < res.size(); i++) {

			if (!(res.get(i).name.equals(CustomerName))) {

				flag = -1;

			}

			else {

				flag = i;

				break;

			}

		}

		if (flag == -1) {

			System.out.println("Invalid User..");

		}

		Customer cust = new Customer();

		do {

			if (flag != -1) {
				System.out.println("Enter the choice:");

				System.out.println("1.Withdrawal");

				System.out.println("2.Deposit");

				System.out.println("3.MiniStatement");

				System.out.println("4.Exit");

				ch = sc.nextInt();

				switch (ch) {

				case 1:

					cust.withdrwal(res, flag);

					break;

				case 2:

					cust.deposit(res, flag);

					break;

				case 3:

					cust.display(res, flag);

					break;

				case 4:

					System.out.println("Welcome..Please Visit us again!!!!!!!");

					break;

				default:

					System.out.println(ch + "which you entered is not Valid!!!!");

				}

			}
		} while (!(ch == 4));

	}

}
