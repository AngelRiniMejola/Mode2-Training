import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Repeatable(Students.class)
@interface Student {

	int age();

	String name();

	long phoneNo();

	String accNo();

	float bal();
}

@Retention(RetentionPolicy.RUNTIME)
@interface Students {
	Student[] value();
}

@Student(age = 21, name = "Divya", phoneNo = 9698741230l, accNo = "SBI14587", bal = 60000.06f)
@Student(age = 22, name = "Appa", phoneNo = 8956321470l, accNo = "SBI02596", bal = 10000.06f)
@Student(age = 23, name = "Amma", phoneNo = 1258746930l, accNo = "SBI48596", bal = 20000.06f)
@Student(age = 24, name = "Saranya", phoneNo = 5896320147l, accNo = "SBI75896", bal = 30000.06f)
@Student(age = 25, name = "Sangee", phoneNo = 9632587410l, accNo = "SBI22559", bal = 40000.06f)
@Student(age = 26, name = "Jai", phoneNo = 8521479630l, accNo = "SBI36985", bal = 50000.06f)
@Student(age = 27, name = "Priya", phoneNo = 2365147890l, accNo = "SBI14774", bal = 70000.06f)
@Student(age = 28, name = "Nirmal", phoneNo = 4125639870l, accNo = "SBI96968", bal = 80000.06f)
@Student(age = 29, name = "Vani", phoneNo = 6874593201l, accNo = "SBI99668", bal = 90000.06f)
@Student(age = 30, name = "Murugan", phoneNo = 7788996655l, accNo = "SBI33665", bal = 100000.06f)

public class AnnotationClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student[] stud = AnnotationClass.class.getAnnotationsByType(Student.class);
		for (Student student : stud) {
			System.out.println(student.age() + "\t" + student.name() + "\t" + student.phoneNo() + "\t" + student.accNo()
					+ "\t" + student.bal());
		}
	}

}
