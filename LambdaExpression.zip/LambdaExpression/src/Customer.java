import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

public class Customer {
	@NotNull
	public int age;
	public String name;
	public long phoneNo;
	public String accNo;
	@Positive
	public float bal;

	float amount;

	List<String> mini = new ArrayList<String>();

	public Customer(int age, String name, long phoneNo, String accNo, float bal) {
		super();
		this.age = age;
		this.name = name;
		this.phoneNo = phoneNo;
		this.accNo = accNo;
		this.bal = bal;
	}

	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAccNo() {
		return accNo;
	}

	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

	public float getBal() {
		return bal;
	}

	public void setBal(float bal) {
		this.bal = bal;
	}

	public void withdrwal(List<Customer> ans, int flag) {

		System.out.println("Please enter the amount tobe withdrawn");

		Scanner sc = new Scanner(System.in);

		float amount = sc.nextFloat();

		if (ans.get(flag).bal < amount)

		{

			System.out.println("Your balance is less..");

		}

		else {

			bal = ans.get(flag).bal - amount;

			ans.get(flag).bal = bal;

			String s = "Withdrawn:" + amount;

			ans.get(flag).mini.add(s);

		}

	}

	public void deposit(List<Customer> ans, int flag) {

		System.out.println("Please enter the amount tobe deposited");

		Scanner sc = new Scanner(System.in);

		float deposit = sc.nextFloat();

		bal = ans.get(flag).bal + deposit;

		ans.get(flag).bal = bal;

		String s1 = "Deposited:" + deposit;

		ans.get(flag).mini.add(s1);

	}

	int k = 1;

	public void display(List<Customer> ans, int flag) {

		System.out.println("**********Your Transactions*************");

		System.out.println("Name:" + ans.get(flag).name + "" + "age:" + ans.get(flag).age + "" + "PhoneNo:"
				+ ans.get(flag).phoneNo);

		System.out.println("Available balance is " + ans.get(flag).bal);

		for (int i = ans.get(flag).mini.size() - 1; i >= 0; i--) {

			System.out.println(k + "." + ans.get(flag).mini.get(i));

			System.out.println();

			k++;

			if (k == 11) {

				break;

			}

		}
	}
}
