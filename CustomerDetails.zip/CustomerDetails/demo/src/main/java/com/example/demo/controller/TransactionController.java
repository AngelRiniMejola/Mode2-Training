package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Account;
import com.example.demo.model.Transaction;
import com.example.demo.dto.SendData;
import com.example.demo.service.TransactionService;

@RestController
public class TransactionController {
	@Autowired
	TransactionService service;

	@PostMapping(value = "transaction/check")
	public String doTransaction(@RequestBody SendData data) {
		String status = service.checkBalance(data);
		return status;
	}

	@GetMapping(value = "transaction/getAll")
	public ResponseEntity<List<Transaction>> getAllTransactions(@RequestParam(defaultValue = "1") Integer pageNo,
			@RequestParam(defaultValue = "5") Integer pageSize, @RequestParam(defaultValue = "accnum") String sortBy) {
		List<Transaction> list = service.getAllTransactions(pageNo, pageSize, sortBy);

		return new ResponseEntity<List<Transaction>>(list, new HttpHeaders(), HttpStatus.OK);
	}
}
