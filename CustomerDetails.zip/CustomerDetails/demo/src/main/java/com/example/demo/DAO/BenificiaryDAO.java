package com.example.demo.DAO;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Benificiary;

@Repository
public interface BenificiaryDAO extends CrudRepository<Benificiary, String> {
	public Benificiary findByIFSCCode(String iFSCCode);

	public Benificiary findAllByIFSCCode(String iFSCCode);

}
