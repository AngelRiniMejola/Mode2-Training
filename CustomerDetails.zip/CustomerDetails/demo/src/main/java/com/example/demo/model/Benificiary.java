package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BenificiaryTable")
public class Benificiary {
	@Column(name = "custid")
	int custid;

	@Id
	@Column(name = "bAccNo")
	String bAccNo;

	@Column(name = "IFSCCode")
	String iFSCCode;

	public Integer getCustid() {
		return custid;
	}

	public void setCustid(Integer custid) {
		this.custid = custid;
	}

	public String getbAccNo() {
		return bAccNo;
	}

	public void setbAccNo(String bAccNo) {
		this.bAccNo = bAccNo;
	}

	public String getIFSCCode() {
		return iFSCCode;
	}

	public void setIFSCCode(String iFSCCode) {
		this.iFSCCode = iFSCCode;
	}

}
