package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.BenificiaryDAO;
import com.example.demo.model.Benificiary;

@Service
public class BenificiaryService {

	@Autowired
	BenificiaryDAO benificiaryDAO;

	List<BenificiaryDAO> list = new ArrayList<BenificiaryDAO>();

	// To add Benificiary Account
	public String addBenifDetails(Benificiary benificiary) {
		benificiary.setbAccNo(benificiary.getbAccNo());
		benificiary.setCustid(benificiary.getCustid());
		benificiary.setIFSCCode(benificiary.getIFSCCode());
		benificiaryDAO.save(benificiary);
		return "Succefully Added to Benificiary Account";
	}

	// To find Benificiary account by IFSC code
	public Benificiary benificiaryDetails(String iFSCCode) {
		return benificiaryDAO.findByIFSCCode(iFSCCode);
	}

}
