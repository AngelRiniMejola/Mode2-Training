package com.example.demo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.REQUESTED_RANGE_NOT_SATISFIABLE)
public class BalanceInsufficientException extends RuntimeException {
	private static final long SerialVersionUId = 1L;

	public BalanceInsufficientException(String exception1) {
		super(exception1);
	}
}
