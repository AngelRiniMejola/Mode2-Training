package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.AccountDao;
import com.example.demo.DAO.TransactionDao;
import com.example.demo.model.Account;
import com.example.demo.dto.SendData;
import com.example.demo.exception.AccountNotFoundException;
import com.example.demo.model.Transaction;

@Service
public class TransactionService {
	@Autowired
	TransactionDao tDao;
	@Autowired
	AccountDao adao;

	ModelMapper mapper = new ModelMapper();
	List<SendData> list = new ArrayList<SendData>();

	// To check balance of Customer
	public String checkBalance(com.example.demo.dto.SendData data) {
		Account a = new Account();
		list.add(mapper.map(a, SendData.class));
		Account a1 = adao.findById(data.getFromaccno()).orElse(null);
		if (a1 == null) {
			throw new AccountNotFoundException("fromaccno-" + data.getFromaccno());

		}
		Account a2 = adao.findById(data.getToaccno()).orElse(null);
		if (a2 == null) {
			throw new AccountNotFoundException("toaccno-" + data.getToaccno());

		}

		if (data.getFromaccno() != data.getToaccno() && a1.getBalance() > data.getAmount()) {
			String str = addtransaction(data, a1);
			String str1 = totransaction(data, a2);
			return str;
		} else {
			String str1 = totransaction(data, a1);
		}
		return "Account not found";
	}

	public String addtransaction(SendData Data, Account a1) {
		Transaction t = new Transaction();
		t.setAccnum(Data.getFromaccno());
		t.setAmount(Data.getAmount());
		t.setType("Debit");
		t.setDescription("amount send");
		tDao.save(t);
		int amount = a1.getBalance() - Data.getAmount();
		a1.setBalance(amount);
		adao.save(a1);
		return "Transaction Successfull";
	}

	public String totransaction(SendData Data, Account a1) {
		Transaction t = new Transaction();
		t.setAccnum(Data.getToaccno());
		t.setAmount(Data.getAmount());
		t.setType("Credit");
		t.setDescription("amount received");
		tDao.save(t);
		int amount = a1.getBalance() + Data.getAmount();
		a1.setBalance(amount);
		adao.save(a1);
		return "Transaction Successfull";
	}

	// To get all the Transactions
	public List<Transaction> getAllTransactions(Integer pageNo, Integer pageSize, String sortBy) {
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));
		Page<Transaction> pagedResult = tDao.findAll(paging);
		if (pagedResult.hasContent()) {
			return pagedResult.getContent();
		} else {
			return new ArrayList<Transaction>();
		}

	}
}
