package com.example.service;

import java.util.Optional;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.example.demo.DAO.CustomerDao;
import com.example.demo.model.Customer;
import com.example.demo.service.CustomerServiceImpl;



@RunWith(MockitoJUnitRunner.Silent.class)
public class CustomerServiceImplTest {

	@InjectMocks
	CustomerServiceImpl customerservice;
	
	@Mock
	CustomerDao custDao;
	
	@Test
	public void testGetCustomerById() {
		Customer customer=new Customer();
		customer.setName("customer1");
		customer.setEmpId(2);
		customer.setAge(50);
		customer.setPassword("12345");
		Optional<Customer> users = Optional.of(customer);
		
		Mockito.when(custDao.findById(1)).thenReturn(users);
		Customer customerRes=customerservice.getCustomerById(1);
		Assert.assertNotNull(customerRes);
	}
	
	@Test
	public void testupdateCustomer() {
		Customer customer=new Customer();
		customer.setName("customer1");
		customer.setEmpId(2);
		customer.setAge(50);
		customer.setPassword("12345");
		Optional<Customer> users = Optional.of(customer);
		
		Mockito.when(custDao.findById(1)).thenReturn(users);
		customerservice.updateCustomer(1,customer);
		//Assert.assertNotNull(customerservice.updateCustomer(1,customer));
	
	}

}
