

 package com.example.controller;
 

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.demo.controller.CustomerController;
import com.example.demo.dto.CustomerDto;
import com.example.demo.model.Customer;
import com.example.demo.service.CustomerServiceImpl;




@RunWith(MockitoJUnitRunner.Silent.class)
public class CustomerControllerTest {
	@InjectMocks
	CustomerController customerController;

	@Mock
	CustomerServiceImpl custService;

	private MockMvc mockMvc;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		
		mockMvc = MockMvcBuilders.standaloneSetup(customerController)
                .build();
	}
	
	@Test
	public void testGetAllcustomers(){
		List<CustomerDto> customer = new ArrayList<>();
		CustomerDto user = new CustomerDto();
		user.setName("AAA");;
		user.setAge(25);
		customer.add(user);
		Mockito.when(custService.getAllCustomers()).thenReturn(customer);
		List<CustomerDto> resp = customerController.getAllcustomers();
		
	}
	
	@Test
	public void testDeleteCustomers(){
		Customer customer=new Customer();
		customer.setEmpId(1);
		customer.setName("AAA");
		String str="deleted";
		Mockito.when(custService.deleteCustomers(1)).thenReturn(str);
		customerController.deleteCustomers(1);
		
	}
	
	/*
	@Test
	public void testUpdateCustomers(){
		Customer customer=new Customer();
		customer.setEmpId(1);
		customer.setName("AAA");
		
		Mockito.when(custService.updateCustomer(1, customer));
				customerController.UpdateCustomers(1, customer);
		
	}
	*/
}
