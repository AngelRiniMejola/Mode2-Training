package com.calc.webservice;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			CalculatorServiceStub stub = new CalculatorServiceStub();
			CalculatorServiceStub.Addition params = new CalculatorServiceStub.Addition();
			params.setA(40);
			params.setB(50);

			CalculatorServiceStub.AdditionResponse response = stub.addition(params);
			int result = response.get_return();
			System.out.println("Result is: "+result);
			
			
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
