package com.pack.securitty;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class SecurityController {
	
	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public String securityModel(Model model) {
		System.out.println("Returning user.jsp page");
		return "user";
	}
	
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public String securityModelll(Model model) {
		System.out.println("Returning admin.jsp page");
		return "admin";
	}

}
