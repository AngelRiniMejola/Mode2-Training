package com.springmvc.pack.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springmvc.pack.dao.CustomerDao;
import com.springmvc.pack.model.Customer;

@Service
public class CustomerService {
	@Autowired
	private CustomerDao customerDao;

	//To add person Detail
	@Transactional
	public void addPerson(Customer cust) {
		customerDao.addPerson(cust);
	}

	//To list all persons
	@Transactional
	public List<Customer> listPersons() {
		return customerDao.getEmployee();
	}
}
