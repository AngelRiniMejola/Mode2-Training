package com.springmvc.pack.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springmvc.pack.model.Customer;

@Repository
public class CustomerDao {
	private static final Logger logger = LoggerFactory.getLogger(CustomerDao.class);

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	public void addPerson(Customer cust) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(cust);
		logger.info("Person saved successfully, Person Details=" + cust);
	}

	@Transactional
	public List<Customer> getEmployee() {
		Session session = this.sessionFactory.openSession();
		List<Customer> list = (List<Customer>) session.createQuery("from Customer").list();
		session.close();
		return list;
	}

}
