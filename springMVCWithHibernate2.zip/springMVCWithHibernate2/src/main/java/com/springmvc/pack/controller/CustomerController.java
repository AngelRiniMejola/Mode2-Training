package com.springmvc.pack.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.springmvc.pack.model.Customer;
import com.springmvc.pack.service.CustomerService;

@Controller
public class CustomerController {

	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

	@Autowired
	private CustomerService customerService;
	private Map<String, Customer> cust = null;

	public CustomerController() {
		cust = new HashMap<String, Customer>();
	}

	@ModelAttribute("cust")
	public Customer createUserModel() {
		return new Customer();
	}

	@RequestMapping(value = "/cust/add", method = RequestMethod.GET)
	public String addCustomer(Model model) {
		logger.info("Returning cust_details.jsp page");
		return "cust_details";
	}

	@RequestMapping(value = "/cust/save.do", method = RequestMethod.POST)
	public String saveCustomerAction(@ModelAttribute("cust") @Validated Customer cust, BindingResult bindingResult,
			Model model) {
		if (bindingResult.hasErrors()) {
			logger.info("Returning cust_details.jsp page");
			return "cust_details";
		}
		logger.info("Returning cust_success.jsp page");
		model.addAttribute("cust", cust);
		this.customerService.addPerson(cust);
		this.customerService.listPersons();
		return "cust_success";
	}
}