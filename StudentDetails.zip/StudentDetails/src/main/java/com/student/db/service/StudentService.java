package com.student.db.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.student.db.Dao.StudentDao;
import com.student.db.model.Academic;
import com.student.db.model.Colleges;
import com.student.db.model.Student;
import com.student.db.model.dto.StudentDto;

@Service
public class StudentService {

	@Autowired
	StudentDao studentDao;

	@Transactional
	public void addStudent(Student student1, Academic academic) {
		studentDao.addStudent(student1, academic);
	}

	@Transactional
	public Colleges getPlace(StudentDto student) {
		return studentDao.getPlace(student);

	}

	@Transactional
	public List<Student> getAll(int id, int total) {
		return studentDao.getAll(id, total);
	}

	@Transactional
	public List<Student> getDetails() {
		return studentDao.getDetails();
	}

}
