package com.student.db.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "college")
public class Colleges implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column
	String collegeCode;
	@Column
	String collegeName;
	@Column
	String place;

	public String getCollegeCode() {
		return collegeCode;
	}

	public void setCollegeCode(String collegeCode) {
		this.collegeCode = collegeCode;
	}

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	@Override
	public String toString() {
		return "Colleges [collegeCode=" + collegeCode + ", collegeName=" + collegeName + ", place=" + place + "]";
	}

}
