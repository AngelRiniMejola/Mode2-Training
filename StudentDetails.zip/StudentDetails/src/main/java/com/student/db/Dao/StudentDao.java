package com.student.db.Dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.student.db.model.Academic;
import com.student.db.model.Colleges;
import com.student.db.model.Student;
import com.student.db.model.dto.StudentDto;

@Repository
public class StudentDao {
	private static final Logger logger = LoggerFactory.getLogger(StudentDao.class);

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	public void addStudent(Student student1, Academic academic) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(student1);
		session.save(academic);
		logger.info("Student saved successfully, Student Details=" + student1.toString());
	}

	public Colleges getPlace(StudentDto student) {
		Session session = this.sessionFactory.getCurrentSession();
		String hql1 = "from Student  clg  where clg.usn = :collegeCode";
		List<Colleges> result = session.createQuery(hql1).setString("collegeCode", student.getUsn()).list();
		if (result.size() != 0) {
			String str = student.getUsn().substring(0, 2);
			System.out.println(str);
			String hql = "from Colleges  clg  where clg.collegeCode = :collegeCode";
			List<Colleges> result1 = session.createQuery(hql).setString("collegeCode", str).list();
			System.out.println(result1.toString());
			return result1.get(0);
		} else {
			return null;
		}
	}

	public List<Student> getAll(int id, int total) {
		String hql1 = "from Student";
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery(hql1);
		query.setFirstResult(id - 1);
		query.setMaxResults(total);
		List<Student> getAll = query.list();
		return getAll;
	}

	public List<Student> getDetails() {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria cb = session.createCriteria(Student.class);
		List<Student> list = cb.list();
		return list;
	}

}
