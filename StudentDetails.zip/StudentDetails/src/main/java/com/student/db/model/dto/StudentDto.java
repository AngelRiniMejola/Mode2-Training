package com.student.db.model.dto;

public class StudentDto {
	String usn;
	String name;
	int age;
	long phno;
	String email;
	String fatherName;
	String motherName;
	double percentage;
	String course;
	String sem;

	public String getUsn() {
		return usn;
	}

	public void setUsn(String usn) {
		this.usn = usn;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getPhno() {
		return phno;
	}

	public void setPhno(long phno) {
		this.phno = phno;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getSem() {
		return sem;
	}

	public void setSem(String sem) {
		this.sem = sem;
	}

	@Override
	public String toString() {
		return "StudentDto [usn=" + usn + ", name=" + name + ", age=" + age + ", phno=" + phno + ", email=" + email
				+ ", fatherName=" + fatherName + ", motherName=" + motherName + ", percentage=" + percentage
				+ ", course=" + course + ", sem=" + sem + "]";
	}

}
