package com.student.db.Dao;

import org.springframework.data.repository.CrudRepository;

import com.student.db.model.Courses;
import com.student.db.model.Key;

public interface CoursesDao extends CrudRepository<Courses, Key> {

}
