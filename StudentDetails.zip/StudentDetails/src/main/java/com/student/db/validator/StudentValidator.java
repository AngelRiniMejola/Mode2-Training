package com.student.db.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.student.db.model.Student;

public class StudentValidator implements Validator {

	@Override
	public boolean supports(Class<?> paramClass) {
		return Student.class.equals(paramClass);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		Student student = (Student) obj;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "name.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "age", "age.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "email.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "course", "course.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "semester", "semester.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "email.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "email.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "email.required");
	}

}
